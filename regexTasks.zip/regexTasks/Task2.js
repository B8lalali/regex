function loginUser() {
  var loginEmail = document.getElementById("loginEmail").value;
  var loginPassword = document.getElementById("loginPassword").value;

  var savedEmail = localStorage.getItem("email");
  var savedPassword = localStorage.getItem("password");
  var savedFirstName = localStorage.getItem("firstName");

  if (loginEmail === savedEmail && loginPassword === savedPassword) {
    document.getElementById("loginMessage").innerHTML = "Welcome " + savedFirstName + "!";
  } else {
    document.getElementById("loginMessage").innerHTML = "Wrong email or password";
  }
}