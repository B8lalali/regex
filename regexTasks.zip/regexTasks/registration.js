function checkForm() {
  var firstName = document.getElementById("firstName").value;
  var lastName = document.getElementById("lastName").value;
  var birthDate = document.getElementById("birthDate").value;
  var email = document.getElementById("email").value;
  var confirmEmail = document.getElementById("confirmEmail").value;
  var password = document.getElementById("password").value;
  var confirmPassword = document.getElementById("confirmPassword").value;
  var mobile = document.getElementById("mobile").value;

  var errors = "";

  var letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ";
  var i;
  var nameIsValid = true;

  for (i = 0; i < firstName.length; i++) {
    if (letters.indexOf(firstName.charAt(i)) === -1) {
      nameIsValid = false;
    }
  }

  if (firstName === "" || nameIsValid === false) {
    errors = errors + "First name must contain letters only<br>";
  }

  var lastNameIsValid = true;
  for (i = 0; i < lastName.length; i++) {
    if (letters.indexOf(lastName.charAt(i)) === -1) {
      lastNameIsValid = false;
    }
  }

  if (lastName === "" || lastNameIsValid === false) {
    errors = errors + "Last name must contain letters only<br>";
  }

  if (birthDate === "") {
    errors = errors + "Please enter your birth date<br>";
  }

  var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (emailPattern.test(email) === false) {
    errors = errors + "Email format is not correct<br>";
  }


  if (email !== confirmEmail) {
    errors = errors + "Emails do not match<br>";
  }


  if (password.length < 8 || password.length > 32) {
    errors = errors + "Password length should be between 8 and 32<br>";
  }

  var firstChar = password.charAt(0);
  if (firstChar < "A" || firstChar > "Z") {
    errors = errors + "Password must start with a capital letter<br>";
  }

  var numberCount = 0;
  var specialCount = 0;

  for (i = 0; i < password.length; i++) {
    var ch = password.charAt(i);

    if (ch >= "0" && ch <= "9") {
      numberCount = numberCount + 1;
    } else if (letters.indexOf(ch) === -1) {
      specialCount = specialCount + 1;
    }
  }

  if (numberCount < 2) {
    errors = errors + "Password must contain at least 2 numbers<br>";
  }

  if (specialCount < 1) {
    errors = errors + "Password must contain at least 1 special character<br>";
  }

  if (password !== confirmPassword) {
    errors = errors + "Passwords do not match<br>";
  }

  var digits = "0123456789";
  var mobileIsValid = true;

  for (i = 0; i < mobile.length; i++) {
    if (digits.indexOf(mobile.charAt(i)) === -1) {
      mobileIsValid = false;
    }
  }

  if (mobile.length !== 10 || mobileIsValid === false) {
    errors = errors + "Mobile number should be 10 digits<br>";
  }

  if (errors === "") {
    document.getElementById("errors").style.color = "green";
    document.getElementById("errors").innerHTML = "Registered successfully!";
  } else {
    document.getElementById("errors").style.color = "red";
    document.getElementById("errors").innerHTML = errors;
  }
}